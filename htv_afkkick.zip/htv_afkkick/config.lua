Config = {
    KickMessage = 'Du warst mehr als 30 Minuten nicht mehr aktiv.',
    AFK_Time = 1800, -- Zeit in Sekunden bis zum Kick
    WarnPlayerBefore = true, -- Warne Spieler vor dem Kick, wenn 3/4 der Zeit vergangen sind
    Config.MessageStyle = 'mythic-notify'   -- 'mythic-notify', 'esx:showNotification', 'console'
}