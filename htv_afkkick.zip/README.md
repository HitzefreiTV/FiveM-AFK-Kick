Very simple AFK-Kick Script

If you're not using ESX, delete the following lines from fxmanifest.lua:

shared_scripts {
	'@es_extended/imports.lua',
}
